<?php

namespace App\Models\LandingPage;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LandingPageAbout extends Model
{
    use HasFactory;
    protected $guarded = [];
}
