<?php

namespace App\Http\Controllers\Midtrans;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MidtransTransactionWifiController extends Controller
{
    //
}
